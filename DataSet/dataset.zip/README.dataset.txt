# Hong Kong Traffic Sign > 2024-11-16 11:25pm
https://universe.roboflow.com/ai-7tpgx/hong-kong-traffic-sign-plzf8

Provided by a Roboflow user
License: CC BY 4.0

